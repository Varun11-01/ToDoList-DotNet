﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace Todo
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            // Registers any MVC Areas (for large projects split into modules)
            AreaRegistration.RegisterAllAreas();

            // Registers global filters (like error handling, auth filters, etc.)
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);

            // 👇 Registers routes from App_Start/RouteConfig.cs
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            // Registers CSS & JS bundles (like Bootstrap, jQuery)
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
    }
}
