﻿namespace Todo.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddPriorityAndDueDate : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Tasks", "Priority", c => c.String());
            AddColumn("dbo.Tasks", "DueDate", c => c.DateTime());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Tasks", "DueDate");
            DropColumn("dbo.Tasks", "Priority");
        }
    }
}
