﻿using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using Todo.Models;

namespace Todo.Controllers
{
    public class TaskController : Controller
    {
        private TodoContext db = new TodoContext();

        // 🏠 INDEX — Show all tasks
        public ActionResult Index()
        {
            var tasks = db.Tasks.OrderByDescending(t => t.CreatedDate).ToList();
            ViewBag.Total = tasks.Count;
            ViewBag.Completed = tasks.Count(t => t.IsCompleted);
            ViewBag.Progress = (ViewBag.Total == 0) ? 0 :
                (int)((ViewBag.Completed * 100.0) / ViewBag.Total);

            return View(tasks);
        }

        // ➕ CREATE — Add new task
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(TaskItem task)
        {
            if (ModelState.IsValid)
            {
                task.CreatedDate = DateTime.Now;
                db.Tasks.Add(task);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(task);
        }

        // ✏️ EDIT — Modify existing task
        public ActionResult Edit(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            var task = db.Tasks.Find(id);
            if (task == null)
                return HttpNotFound();

            return View(task);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(TaskItem task)
        {
            if (ModelState.IsValid)
            {
                db.Entry(task).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(task);
        }

        // 🔁 TOGGLE COMPLETE / UNDO — fixed
        [HttpPost]
        public ActionResult ToggleComplete(int id)
        {
            var task = db.Tasks.Find(id);
            if (task == null)
                return HttpNotFound();

            task.IsCompleted = !task.IsCompleted;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        // ❌ DELETE — Confirm before removing
        public ActionResult Delete(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            var task = db.Tasks.Find(id);
            if (task == null)
                return HttpNotFound();

            return View(task);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var task = db.Tasks.Find(id);
            db.Tasks.Remove(task);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        // 🧹 Dispose
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
