﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Todo.Models
{
    public class TaskItem
    {
        [Key]
        public int TaskId { get; set; }

        [Required(ErrorMessage = "Title is required")]
        [StringLength(100, ErrorMessage = "Title cannot exceed 100 characters")]
        public string Title { get; set; }

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string Description { get; set; }

        public bool IsCompleted { get; set; }

        // ✅ Automatically set valid date when created
        [Required]
        [DataType(DataType.DateTime)]
        public DateTime CreatedDate { get; set; } = DateTime.Now;

        // ✅ Optional due date (nullable to avoid SQL datetime2 conversion issues)
        [DataType(DataType.Date)]
        [Display(Name = "Due Date")]
        public DateTime? DueDate { get; set; }

        // ✅ Task priority with default value — Low / Medium / High
        [Required]
        [StringLength(20)]
        [Display(Name = "Priority Level")]
        [Column(TypeName = "nvarchar")]
        public string Priority { get; set; } = "Medium";
    }
}
