﻿using System.Data.Entity;

namespace Todo.Models
{
    public class TodoContext : DbContext
    {
        public TodoContext() : base("TodoConnection")
        {
            this.Configuration.LazyLoadingEnabled = false;
        }

        public DbSet<TaskItem> Tasks { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TaskItem>().ToTable("Tasks");
            modelBuilder.Entity<TaskItem>().HasKey(t => t.TaskId);
            base.OnModelCreating(modelBuilder);
        }
    }
}
